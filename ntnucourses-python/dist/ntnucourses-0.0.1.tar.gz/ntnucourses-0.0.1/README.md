# NTNU Courses

Course-codes taught at NTNU and their names as key-value pairs in a dictionary fir simple lookups